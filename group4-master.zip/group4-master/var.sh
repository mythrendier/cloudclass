#!/bin/sh
echo "Setting environment variables for Terraform"
export ARM_SUBSCRIPTION_ID=e0fae348-f6c2-45f5-CCCCCCCCCCCCCCCCC
export ARM_CLIENT_ID=e2d142b3-92cb--CCCCCCCCCCCCCCCCC
export ARM_CLIENT_SECRET=48a20ac3-067-CCCCCCCCCCCCCCCCC
export ARM_TENANT_ID=96e3cac9-1ab3-4-CCCCCCCCCCCCCCCCC

# Need to Update the ID and Secret

# Not needed for public, required for usgovernment, german, china
#export ARM_ENVIRONMENT=public
